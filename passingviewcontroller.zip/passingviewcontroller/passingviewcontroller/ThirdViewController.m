//
//  ThirdViewController.m
//  passingviewcontroller
//
//  Created by Dinesh Jaganathan on 04/11/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import "ThirdViewController.h"
#import "SecondViewController.h"
@interface ThirdViewController (){
   
}

@end

@implementation ThirdViewController
@synthesize thirdstring;

- (void)viewDidLoad {
    
    
    appDele= (AppDelegate*)[[UIApplication sharedApplication]delegate];
    
    NSLog(@"%@",appDele.globalString);
    
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
-(IBAction)four:(id)sender{
    
   [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
