//
//  SecondViewController.h
//  passingviewcontroller
//
//  Created by Dinesh Jaganathan on 04/11/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import "ViewController.h"

@interface SecondViewController : ViewController{
    IBOutlet UIButton *secondbutton,*thirdbutton;
    
}


-(IBAction)thirdclick:(id)sender;
@property(nonatomic,retain)NSString *secstring;
@end
