//
//  ViewController.h
//  passingviewcontroller
//
//  Created by Dinesh Jaganathan on 04/11/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
@interface ViewController : UIViewController{
    IBOutlet UIButton *firstbutton;
    
    NSUserDefaults *userDef;
    
    AppDelegate *appDelegate;
    
}
-(IBAction)firstclick:(id)sender;
@property(nonatomic,retain)NSString *five;
@end

