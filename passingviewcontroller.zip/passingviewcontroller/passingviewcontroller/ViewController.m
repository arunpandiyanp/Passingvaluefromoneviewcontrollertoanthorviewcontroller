//
//  ViewController.m
//  passingviewcontroller
//
//  Created by Dinesh Jaganathan on 04/11/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import "ViewController.h"
#import "SecondViewController.h"
#import "ThirdViewController.h"
@interface ViewController ()

@end

@implementation ViewController
@synthesize five;
- (void)viewDidLoad {
    
    
    
    appDelegate = (AppDelegate*)[[UIApplication sharedApplication]delegate];
    appDelegate.globalString= @"tesss";
    
    userDef= [NSUserDefaults standardUserDefaults];
    [userDef setObject:@"Ram" forKey:@"username"];
    [userDef synchronize];
    
    
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
-(IBAction)firstclick:(id)sender{
    SecondViewController *second=[self.storyboard instantiateViewControllerWithIdentifier:@"second"];
    second.secstring=@"first viewcontroller to second value is passed";
    [[self navigationController]pushViewController:second animated:YES];

    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
