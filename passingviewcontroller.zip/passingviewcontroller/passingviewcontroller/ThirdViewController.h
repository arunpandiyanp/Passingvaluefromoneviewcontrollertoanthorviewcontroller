//
//  ThirdViewController.h
//  passingviewcontroller
//
//  Created by Dinesh Jaganathan on 04/11/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"

@interface ThirdViewController : ViewController
{
    IBOutlet UIButton *four;
    AppDelegate *appDele;

}
-(IBAction)four:(id)sender;
@property(nonatomic,retain)NSString *thirdstring;

@end
