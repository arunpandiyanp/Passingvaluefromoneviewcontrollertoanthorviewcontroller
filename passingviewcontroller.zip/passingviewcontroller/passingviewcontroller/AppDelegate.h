//
//  AppDelegate.h
//  passingviewcontroller
//
//  Created by Dinesh Jaganathan on 04/11/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property(nonatomic,retain) NSString *globalString;

@end

