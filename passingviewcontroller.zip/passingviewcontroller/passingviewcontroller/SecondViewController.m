//
//  SecondViewController.m
//  passingviewcontroller
//
//  Created by Dinesh Jaganathan on 04/11/16.
//  Copyright © 2016 Greens. All rights reserved.
//

#import "SecondViewController.h"

#import "ThirdViewController.h"
@interface SecondViewController ()

@end

@implementation SecondViewController
@synthesize secstring;
//@synthesize secstring;


- (void)viewDidLoad {
    NSLog(@"%@",secstring);
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

-(IBAction)thirdclick:(id)sender{
    ThirdViewController *third=[self.storyboard instantiateViewControllerWithIdentifier:@"third"];
    third.thirdstring=@"second to thrid viewcontroller";
    [self presentViewController:third animated:YES completion:nil];
    
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
